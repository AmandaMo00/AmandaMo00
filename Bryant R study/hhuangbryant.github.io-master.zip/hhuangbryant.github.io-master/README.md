# hhuangbryant.github.io

[A1](assi1.html)
<br>[A6](Assignment6.html)
<br>[A7](function.html)
<br>[A8](assignment8.html)
<br>[A9](Assignment9.html)
<br>[A10](A10.html)
<br>[midterm visualization](Mpart1.html) 
<br>[midterm predictive model](Mpart2.html)
